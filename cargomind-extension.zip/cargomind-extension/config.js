// config.js
// Wypełnij poniższe dane swoimi kluczami z Supabase (Project Settings -> API)

export const SUPABASE_URL = "https://epabqsokqoemgiyznbuy.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_I78AExSKJpHC32PveLiHuw_gJlbUR2H";

